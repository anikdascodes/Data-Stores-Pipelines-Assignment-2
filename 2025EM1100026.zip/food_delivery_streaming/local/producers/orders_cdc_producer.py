#!/usr/bin/env python3
"""
Food Delivery Orders CDC Producer
Assignment 2 - Data Stores & Pipelines
Student: Anik Das (2025EM1100026)

This script connects to PostgreSQL, polls for new orders every 5 seconds,
and publishes them as JSON events to Kafka topic.

Note: This is my first time working with CDC patterns, so I had to do some research.
The SQL injection fix was tricky but I think I got it right!
"""

import argparse
import json
import time
import os
from datetime import datetime
import yaml
import psycopg2
from psycopg2 import sql
from pyspark.sql import SparkSession
from pyspark.sql.functions import to_json, struct, lit
from pyspark.sql.types import TimestampType

def load_config(config_path):
    """Load configuration from YAML file"""
    with open(config_path, 'r') as file:
        return yaml.safe_load(file)

def get_last_processed_timestamp(timestamp_file):
    """Get the last processed timestamp from file"""
    if os.path.exists(timestamp_file):
        with open(timestamp_file, 'r') as f:
            timestamp = f.read().strip()
            if timestamp:
                return timestamp
    return "1970-01-01 00:00:00"

def save_last_processed_timestamp(timestamp_file, timestamp):
    """Save the last processed timestamp to file"""
    os.makedirs(os.path.dirname(timestamp_file), exist_ok=True)
    with open(timestamp_file, 'w') as f:
        f.write(str(timestamp))

def create_json_event(row):
    """Convert row to JSON format as specified in assignment
    TODO: Maybe add more validation here later?"""
    return {
        "order_id": int(row.order_id),
        "customer_name": str(row.customer_name),
        "restaurant_name": str(row.restaurant_name),
        "item": str(row.item),
        "amount": float(row.amount),
        "order_status": str(row.order_status),
        "created_at": row.created_at.strftime("%Y-%m-%dT%H:%M:%SZ") if row.created_at else None
        # Note: The assignment says to use this exact format, so I'm following it strictly
    }

def main():
    # Parse command line arguments
    parser = argparse.ArgumentParser(description='Food Orders CDC Producer')
    parser.add_argument('--config', required=True, help='Path to configuration file')
    args = parser.parse_args()
    
    # Load configuration
    config = load_config(args.config)
    
    # Initialize Spark session
    spark = SparkSession.builder \
        .appName("FoodOrdersCDCProducer") \
        .config("spark.jars.packages", "org.postgresql:postgresql:42.7.3") \
        .getOrCreate()
    
    # Set up JDBC connection properties
    jdbc_url = config['postgres']['jdbc_url']
    jdbc_properties = {
        "user": config['postgres']['user'],
        "password": config['postgres']['password'],
        "driver": "org.postgresql.Driver"
    }
    
    table_name = config['postgres']['table']
    timestamp_file = os.path.join(config['streaming']['last_processed_timestamp_location'], "last_timestamp.txt")
    
    print(f"Starting CDC Producer for table: {table_name}")
    print(f"Kafka topic: {config['kafka']['topic']}")
    print(f"Polling interval: {config['streaming']['batch_interval']} seconds")
    
    try:
        while True:
            try:
                # Get last processed timestamp
                last_timestamp = get_last_processed_timestamp(timestamp_file)
                print(f"Polling for records created after: {last_timestamp}")
                
                # Query for new records using created_at > last_processed_timestamp
                # Use proper escaping to prevent SQL injection

                # Safely escape the table name and timestamp
                safe_table = sql.Identifier(table_name)
                safe_timestamp = sql.Literal(last_timestamp)

                query = sql.SQL("""
                    SELECT order_id, customer_name, restaurant_name, item, amount, order_status, created_at
                    FROM {safe_table}
                    WHERE created_at > {safe_timestamp}
                    ORDER BY created_at ASC
                """).format(safe_table=safe_table, safe_timestamp=safe_timestamp)
                
                # Read new records from PostgreSQL
                df = spark.read.jdbc(
                    url=jdbc_url,
                    table=f"({query}) as new_orders",
                    properties=jdbc_properties
                )
                
                record_count = df.count()
                
                if record_count > 0:
                    print(f"Found {record_count} new orders")
                    
                    # Convert DataFrame to JSON format
                    json_records = []
                    for row in df.collect():
                        json_event = create_json_event(row)
                        json_records.append(json.dumps(json_event))
                    
                    # Create DataFrame with JSON records
                    json_df = spark.createDataFrame(
                        [(record,) for record in json_records], 
                        ["value"]
                    )
                    
                    # Publish to Kafka topic
                    json_df.write \
                        .format("kafka") \
                        .option("kafka.bootstrap.servers", config['kafka']['brokers']) \
                        .option("topic", config['kafka']['topic']) \
                        .save()
                    
                    # Update last processed timestamp
                    max_timestamp = df.agg({"created_at": "max"}).collect()[0][0]
                    save_last_processed_timestamp(timestamp_file, str(max_timestamp))
                    
                    print(f"Successfully published {record_count} orders to Kafka topic: {config['kafka']['topic']}")
                    print(f"Updated last processed timestamp to: {max_timestamp}")
                    
                else:
                    print("No new orders found")
                
                # Wait for next polling interval
                print(f"Waiting {config['streaming']['batch_interval']} seconds for next poll...")
                time.sleep(config['streaming']['batch_interval'])
                
            except Exception as e:
                print(f"Error during polling: {e}")
                print(f"Retrying in {config['streaming']['batch_interval']} seconds...")
                time.sleep(config['streaming']['batch_interval'])
                
    except KeyboardInterrupt:
        print("CDC Producer stopped by user")
    finally:
        spark.stop()
        print("CDC Producer shutdown complete")

if __name__ == "__main__":
    main()