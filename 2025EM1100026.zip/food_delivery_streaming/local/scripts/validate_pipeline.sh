#!/bin/bash

# Pipeline Validation Script
# Assignment 2 - Data Stores & Pipelines
# Student: Anik Das (2025EM1100026)

# Note: This is my first bash script for validation, so it might be a bit rough!

# Configuration - I had to adjust these a few times
CONFIG_FILE="configs/orders_stream.yml"
LOG_FILE="pipeline_validation.log"
TEST_RECORDS=5  # Using 5 records for testing

echo "=== Food Delivery Pipeline Validation ==="
echo "Starting validation... (this might take a minute)"
echo "Validation started at: $(date)" > $LOG_FILE

# Function to log messages
log_message() {
    echo "$1" >> $LOG_FILE
    echo "$1"
}

# 1. Check config file
echo "1. Checking configuration file..."
if [ -f "$CONFIG_FILE" ]; then
    log_message "✓ Configuration file found"
else
    log_message "✗ Configuration file missing: $CONFIG_FILE"
    exit 1
fi

# 2. Test database (this was tricky to get right!)
echo "2. Testing database connection..."
DB_TEST=$(docker exec postgres_food_delivery pg_isready -U student -d food_delivery_db 2>&1)
if echo "$DB_TEST" | grep -q "accepting connections"; then
    log_message "✓ Database is running"
else
    log_message "✗ Database not ready: $DB_TEST"
    exit 1
fi

# 3. Test Kafka
echo "3. Testing Kafka connection..."
KAFKA_TEST=$(docker exec kafka_food_delivery kafka-topics --list --bootstrap-server kafka:9092 2>&1)
if [ $? -eq 0 ]; then
    log_message "✓ Kafka is running"
else
    log_message "✗ Kafka not ready: $KAFKA_TEST"
    exit 1
fi

# 4. Test Spark
echo "4. Testing Spark..."
SPARK_TEST=$(docker exec spark_master_food_delivery spark-submit --version 2>&1)
if echo "$SPARK_TEST" | grep -q "version"; then
    log_message "✓ Spark is ready"
else
    log_message "✗ Spark not ready"
    exit 1
fi

# 5. Simple end-to-end test
echo "5. Running simple end-to-end test..."
echo "Inserting test records..."
docker exec postgres_food_delivery psql -U student -d food_delivery_db -c "
INSERT INTO orders_2025em1100026 (customer_name, restaurant_name, item, amount, order_status)
VALUES ('Validation Test', 'Test Restaurant', 'Test Item', 100.00, 'PLACED');
"

# Wait a bit for processing
echo "Waiting for processing..."
sleep 10

# Check if it worked
echo "Checking results..."
DATA_LAKE_TEST=$(docker exec spark_master_food_delivery find /datalake/output/orders/ -name "*.parquet" 2>/dev/null | wc -l)
if [ $DATA_LAKE_TEST -gt 0 ]; then
    log_message "✓ Pipeline seems to be working! Found $DATA_LAKE_TEST parquet files"
else
    log_message "⚠ No parquet files found yet (might need more time or check logs)"
fi

echo "=== Validation Complete ==="
echo "Check $LOG_FILE for details"
echo "If everything passed, the pipeline should be working!"
exit 0