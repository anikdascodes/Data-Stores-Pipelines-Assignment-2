#!/bin/bash
# Insert test data for incremental testing
# Assignment 2 - Data Stores & Pipelines
# Student: Anik Das (2025EM1100026)

echo "Inserting test data for incremental testing..."
echo ""

# Insert 5 new records as specified in assignment
SQL_QUERY="
INSERT INTO 2025EM1100026_orders (customer_name, restaurant_name, item, amount, order_status) VALUES
('Test User 1', 'Test Restaurant 1', 'Test Burger', 150.00, 'PLACED'),
('Test User 2', 'Test Restaurant 2', 'Test Pizza', 250.00, 'PLACED'),
('Test User 3', 'Test Restaurant 3', 'Test Sandwich', 180.00, 'PLACED'),
('Test User 4', 'Test Restaurant 4', 'Test Pasta', 320.00, 'PLACED'),
('Test User 5', 'Test Restaurant 5', 'Test Salad', 200.00, 'PLACED');
"

echo "Executing SQL query..."
docker exec postgres_food_delivery psql -U student -d food_delivery_db -c "$SQL_QUERY"

if [ $? -eq 0 ]; then
    echo "✅ Successfully inserted 5 test records"
else
    echo "❌ Failed to insert test records"
fi

echo ""
echo "Current order count:"
docker exec postgres_food_delivery psql -U student -d food_delivery_db -c "SELECT COUNT(*) as total_orders FROM 2025EM1100026_orders;"

echo ""
echo "Latest 5 orders:"
docker exec postgres_food_delivery psql -U student -d food_delivery_db -c "SELECT order_id, customer_name, restaurant_name, item, amount, order_status, created_at FROM 2025EM1100026_orders ORDER BY created_at DESC LIMIT 5;"