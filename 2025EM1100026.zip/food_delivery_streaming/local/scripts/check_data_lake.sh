#!/bin/bash
# Check Data Lake contents
# Assignment 2 - Data Stores & Pipelines
# Student: Anik Das (2025EM1100026)

echo "Checking Data Lake contents..."
echo "Data Lake path: /datalake/food/2025EM1100026/output/orders"
echo ""

# List directory structure
echo "Directory structure:"
docker exec spark-worker find /datalake/food/2025EM1100026/output/orders -type d | sort

echo ""
echo "Parquet files:"
docker exec spark-worker find /datalake/food/2025EM1100026/output/orders -name "*.parquet" | head -10

echo ""
echo "Total parquet files:"
docker exec spark-worker find /datalake/food/2025EM1100026/output/orders -name "*.parquet" | wc -l

echo ""
echo "Date partitions:"
docker exec spark-worker ls -la /datalake/food/2025EM1100026/output/orders/ | grep "date="

echo ""
echo "Checkpoint directory:"
docker exec spark-worker ls -la /datalake/food/2025EM1100026/checkpoints/orders/ 2>/dev/null || echo "No checkpoint data found"