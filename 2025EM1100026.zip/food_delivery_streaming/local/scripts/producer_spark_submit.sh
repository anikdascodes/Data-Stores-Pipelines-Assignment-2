#!/bin/bash
# Spark Submit script for Food Orders CDC Producer
# Assignment 2 - Data Stores & Pipelines
# Student: Anik Das (2025EM1100026)

# Activate virtual environment if it exists
if [ -f "de_env/bin/activate" ]; then
    source de_env/bin/activate
fi

# Submit the CDC Producer job
echo "Submitting Food Orders CDC Producer job..."
echo "Config: configs/orders_stream.yml"
echo "Topic: 2025EM1100026_food_orders_raw"

spark-submit \
    --packages org.postgresql:postgresql:42.7.3 \
    --name "FoodOrdersCDCProducer_2025EM1100026" \
    producers/orders_cdc_producer.py \
    --config configs/orders_stream.yml

echo "CDC Producer job submitted successfully"