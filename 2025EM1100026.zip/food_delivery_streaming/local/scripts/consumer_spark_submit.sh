#!/bin/bash
# Spark Submit script for Food Orders Stream Consumer
# Assignment 2 - Data Stores & Pipelines
# Student: Anik Das (2025EM1100026)

# Activate virtual environment if it exists
if [ -f "de_env/bin/activate" ]; then
    source de_env/bin/activate
fi

# Submit the Stream Consumer job
echo "Submitting Food Orders Stream Consumer job..."
echo "Config: configs/orders_stream.yml"
echo "Topic: 2025EM1100026_food_orders_raw"
echo "Output: /datalake/food/2025EM1100026/output/orders"

spark-submit \
    --packages org.apache.spark:spark-sql-kafka-0-10_2.12:3.4.1 \
    --name "FoodOrdersStreamConsumer_2025EM1100026" \
    consumers/orders_stream_consumer.py \
    --config configs/orders_stream.yml

echo "Stream Consumer job submitted successfully"