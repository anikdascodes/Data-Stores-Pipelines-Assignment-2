#!/bin/bash
# Start Docker infrastructure for Food Delivery Streaming Pipeline
# Assignment 2 - Data Stores & Pipelines
# Student: Anik Das (2025EM1100026)

echo "Starting Food Delivery Streaming Pipeline Infrastructure..."
echo "This will start: PostgreSQL, Kafka, Zookeeper, Spark Master & Worker"
echo ""

# Create necessary directories
echo "Creating necessary directories..."
mkdir -p datalake/{output,checkpoints,lastprocess}/orders
mkdir -p logs

# Start Docker containers
echo "Starting Docker containers..."
docker compose up -d

# Wait for services to be ready
echo ""
echo "Waiting for services to start..."
sleep 30

# Check service status
echo ""
echo "Checking service status..."
docker compose ps

echo ""
echo "Infrastructure started successfully!"
echo ""
echo "Service URLs:"
echo "- PostgreSQL: localhost:5432 (food_delivery_db)"
echo "- Kafka: localhost:9092 (2025EM1100026_food_orders_raw)"
echo "- Spark Master UI: http://localhost:8080"
echo "- Spark Worker UI: http://localhost:8081"
echo ""
echo "Data Lake: ./datalake/output/orders"
echo ""
echo "Next steps:"
echo "1. Run: ./scripts/test_connection.sh"
echo "2. Run: ./scripts/producer_spark_submit.sh"
echo "3. Run: ./scripts/consumer_spark_submit.sh"