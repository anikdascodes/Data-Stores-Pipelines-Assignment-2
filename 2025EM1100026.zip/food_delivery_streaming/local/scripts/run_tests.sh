#!/bin/bash

# Comprehensive Test Runner
# Assignment 2 - Data Stores & Pipelines
# Student: Anik Das (2025EM1100026)

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

TEST_DIR="tests"
TEST_REPORT="test_report.txt"
TEST_START=$(date +%s)

echo -e "${BLUE}=== Food Delivery Pipeline Test Suite ===${NC}"
echo -e "Starting comprehensive testing at: $(date)"
echo "Test Suite started at: $(date)" > $TEST_REPORT

# Function to run Python tests
run_python_tests() {
    local test_name=$1
    local test_file=$2

    echo -e "${YELLOW}Running $test_name...${NC}"
    echo "=== $test_name ===" >> $TEST_REPORT

    # Run the test and capture output
    TEST_OUTPUT=$(docker exec -i spark_master_food_delivery python3 $test_file 2>&1)
    TEST_EXIT_CODE=$?

    echo "$TEST_OUTPUT" >> $TEST_REPORT

    if [ $TEST_EXIT_CODE -eq 0 ]; then
        echo -e "${GREEN}✓ $test_name passed${NC}"
        return 0
    else
        echo -e "${RED}✗ $test_name failed${NC}"
        echo "Test output:"
        echo "$TEST_OUTPUT"
        return 1
    fi
}

# Function to run unit tests
run_unit_tests() {
    echo -e "${BLUE}1. Running Unit Tests...${NC}"

    # Run CDC Producer tests
    run_python_tests "CDC Producer Unit Tests" "/opt/bitnami/spark/tests/test_cdc_producer.py"
    PRODUCER_TEST_RESULT=$?

    # Run Stream Consumer tests
    run_python_tests "Stream Consumer Unit Tests" "/opt/bitnami/spark/tests/test_stream_consumer.py"
    CONSUMER_TEST_RESULT=$?

    if [ $PRODUCER_TEST_RESULT -eq 0 ] && [ $CONSUMER_TEST_RESULT -eq 0 ]; then
        echo -e "${GREEN}✓ All unit tests passed${NC}"
        return 0
    else
        echo -e "${RED}✗ Some unit tests failed${NC}"
        return 1
    fi
}

# Function to run integration tests
run_integration_tests() {
    echo -e "${BLUE}2. Running Integration Tests...${NC}"

    # Test database connectivity
    echo -e "${YELLOW}Testing database connectivity...${NC}"
    DB_TEST=$(docker exec postgres_food_delivery psql -U student -d food_delivery_db -c "SELECT 1;" 2>&1)
    if echo "$DB_TEST" | grep -q "1"; then
        echo -e "${GREEN}✓ Database connectivity test passed${NC}"
    else
        echo -e "${RED}✗ Database connectivity test failed${NC}"
        return 1
    fi

    # Test Kafka connectivity
    echo -e "${YELLOW}Testing Kafka connectivity...${NC}"
    KAFKA_TEST=$(docker exec kafka_food_delivery kafka-topics --list --bootstrap-server kafka:9092 2>&1)
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓ Kafka connectivity test passed${NC}"
    else
        echo -e "${RED}✗ Kafka connectivity test failed${NC}"
        return 1
    fi

    # Test end-to-end data flow
    echo -e "${YELLOW}Testing end-to-end data flow...${NC}"

    # Insert test record
    INSERT_TEST=$(docker exec postgres_food_delivery psql -U student -d food_delivery_db -c "
    INSERT INTO orders_2025em1100026 (customer_name, restaurant_name, item, amount, order_status)
    VALUES ('Test User', 'Test Restaurant', 'Test Item', 100.00, 'PLACED');
    " 2>&1)

    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓ Test record inserted successfully${NC}"
    else
        echo -e "${RED}✗ Failed to insert test record${NC}"
        return 1
    fi

    # Wait for processing
    sleep 10

    # Check if record reached Data Lake
    DATA_LAKE_TEST=$(docker exec spark_master_food_delivery find /datalake/output/orders/ -name "*.parquet" 2>/dev/null | wc -l)
    if [ $DATA_LAKE_TEST -gt 0 ]; then
        echo -e "${GREEN}✓ End-to-end data flow test passed${NC}"
        return 0
    else
        echo -e "${YELLOW}⚠ Data Lake files not found yet (may need more time)${NC}"
        return 0  # Don't fail on this as it might be timing issue
    fi
}

# Function to run performance tests
run_performance_tests() {
    echo -e "${BLUE}3. Running Performance Tests...${NC}"

    PERF_START=$(date +%s)

    # Insert 100 test records
    echo -e "${YELLOW}Inserting 100 test records...${NC}"
    for i in {1..100}; do
        docker exec postgres_food_delivery psql -U student -d food_delivery_db -c "
        INSERT INTO orders_2025em1100026 (customer_name, restaurant_name, item, amount, order_status)
        VALUES ('Perf User $i', 'Perf Restaurant $i', 'Perf Item $i', $((100 + i)).00, 'PLACED');
        " > /dev/null 2>&1
    done

    # Wait for processing
    sleep 15

    PERF_END=$(date +%s)
    PERF_TIME=$((PERF_END - PERF_START))

    echo -e "${GREEN}✓ Performance test completed in $PERF_TIME seconds${NC}"
    echo "Performance test: Processed 100 records in $PERF_TIME seconds" >> $TEST_REPORT

    if [ $PERF_TIME -lt 60 ]; then
        echo -e "${GREEN}✓ Performance is good (under 60 seconds)${NC}"
    else
        echo -e "${YELLOW}⚠ Performance could be improved (over 60 seconds)${NC}"
    fi
}

# Function to run validation tests
run_validation_tests() {
    echo -e "${BLUE}4. Running Validation Tests...${NC}"

    # Run the comprehensive validation script
    VALIDATION_OUTPUT=$(./scripts/validate_pipeline.sh 2>&1)
    VALIDATION_EXIT_CODE=$?

    echo "$VALIDATION_OUTPUT" >> $TEST_REPORT

    if [ $VALIDATION_EXIT_CODE -eq 0 ]; then
        echo -e "${GREEN}✓ Pipeline validation passed${NC}"
        return 0
    else
        echo -e "${RED}✗ Pipeline validation failed${NC}"
        return 1
    fi
}

# Main test execution
echo -e "${BLUE}Starting test execution...${NC}"

# Run all test categories
run_unit_tests
UNIT_RESULT=$?

run_integration_tests
INTEGRATION_RESULT=$?

run_performance_tests
PERFORMANCE_RESULT=$?

run_validation_tests
VALIDATION_RESULT=$?

# Generate summary
TEST_END=$(date +%s)
TEST_DURATION=$((TEST_END - TEST_START))

echo -e "${BLUE}=== Test Summary ===${NC}"
echo "Test duration: $TEST_DURATION seconds"
echo "Test completed at: $(date)" >> $TEST_REPORT

# Count passed/failed tests
PASSED=0
FAILED=0

[ $UNIT_RESULT -eq 0 ] && PASSED=$((PASSED + 1)) || FAILED=$((FAILED + 1))
[ $INTEGRATION_RESULT -eq 0 ] && PASSED=$((PASSED + 1)) || FAILED=$((FAILED + 1))
[ $PERFORMANCE_RESULT -eq 0 ] && PASSED=$((PASSED + 1)) || FAILED=$((FAILED + 1))
[ $VALIDATION_RESULT -eq 0 ] && PASSED=$((PASSED + 1)) || FAILED=$((FAILED + 1))

echo -e "Unit Tests: ${GREEN}✓${NC} Passed" $([ $UNIT_RESULT -eq 0 ] && echo "✓" || echo "✗")
echo -e "Integration Tests: ${GREEN}✓${NC} Passed" $([ $INTEGRATION_RESULT -eq 0 ] && echo "✓" || echo "✗")
echo -e "Performance Tests: ${GREEN}✓${NC} Passed" $([ $PERFORMANCE_RESULT -eq 0 ] && echo "✓" || echo "✗")
echo -e "Validation Tests: ${GREEN}✓${NC} Passed" $([ $VALIDATION_RESULT -eq 0 ] && echo "✓" || echo "✗")

echo -e "${BLUE}Overall Results: ${GREEN}$PASSED passed${NC}, ${RED}$FAILED failed${NC}"

if [ $FAILED -eq 0 ]; then
    echo -e "${GREEN}🎉 All tests passed! Pipeline is production-ready.${NC}"
    exit 0
else
    echo -e "${RED}❌ Some tests failed. Check $TEST_REPORT for details.${NC}"
    exit 1
fi