#!/bin/bash
# Test connections to all services
# Assignment 2 - Data Stores & Pipelines
# Student: Anik Das (2025EM1100026)

echo "Testing service connections..."
echo ""

# Test PostgreSQL connection
echo "1. Testing PostgreSQL connection..."
docker exec postgres_food_delivery psql -U student -d food_delivery_db -c "SELECT COUNT(*) as orders_count FROM 2025EM1100026_orders;" 2>/dev/null
if [ $? -eq 0 ]; then
    echo "✅ PostgreSQL connection successful"
else
    echo "❌ PostgreSQL connection failed"
fi

echo ""

# Test Kafka connection
echo "2. Testing Kafka connection..."
docker exec kafka_food_delivery kafka-topics --list --bootstrap-server localhost:9092 2>/dev/null
if [ $? -eq 0 ]; then
    echo "✅ Kafka connection successful"
else
    echo "❌ Kafka connection failed"
fi

echo ""

# Test Spark connection
echo "3. Testing Spark connection..."
curl -s http://localhost:8080 2>/dev/null | grep -q "Spark Master"
if [ $? -eq 0 ]; then
    echo "✅ Spark Master UI accessible"
else
    echo "❌ Spark Master UI not accessible"
fi

echo ""

# Create Kafka topic
echo "4. Creating Kafka topic: 2025EM1100026_food_orders_raw"
docker exec kafka_food_delivery kafka-topics --create --topic 2025EM1100026_food_orders_raw --bootstrap-server localhost:9092 --partitions 1 --replication-factor 1 2>/dev/null || echo "Topic already exists or creation failed"

echo ""
echo "Connection testing complete!"